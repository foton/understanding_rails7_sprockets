function vendor2() {
  console.log("vendor2 executed");
};
