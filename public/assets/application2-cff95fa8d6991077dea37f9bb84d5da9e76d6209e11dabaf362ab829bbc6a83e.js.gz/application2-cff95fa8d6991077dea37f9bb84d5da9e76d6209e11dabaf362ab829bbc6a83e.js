var es6_square = function es6_square(n) {
  return n * n;
};

console.log(es6_square);
