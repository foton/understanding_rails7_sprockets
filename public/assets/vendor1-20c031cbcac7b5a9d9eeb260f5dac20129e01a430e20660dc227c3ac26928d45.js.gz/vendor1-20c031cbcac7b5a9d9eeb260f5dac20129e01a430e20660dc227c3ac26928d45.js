function vendor1() {
  console.log("vendor1 executed");
};
